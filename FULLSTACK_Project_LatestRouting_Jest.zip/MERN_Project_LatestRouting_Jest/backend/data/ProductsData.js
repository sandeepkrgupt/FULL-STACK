const products = [
    {
        name: "Oneplus 9T",
        imageUrl: 'https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-8-2.jpg',
        description: 'Its a hat. You wear it on your head.',
        price: 18000,
        countInStock:100
    
    },{
        name: "Oneplu 8T",
        imageUrl: 'https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-8-polar-silver.jpg',
        description: 'It a beanie. You wear it on your head. 100% Acrylic with leather logo patch',
        price: 45000,
        countInStock:30
    
    },{
        name: "Oneplus Node 2",
        imageUrl: 'https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-8t-lunar.jpg',
        description: 'Make life convenient with a lanyard. You add keys. It goes on your neck.',
        price: 32000,
        countInStock:230
    
    },{
        name: "Oneplus Nord",
        imageUrl: 'https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-nord-1.jpg',
        description: 'Independent Trading Company (55% Cotton / 45% Polyester)',
        price: 25000,
        countInStock:10
    
    }
    ];
    
    module.exports = products;