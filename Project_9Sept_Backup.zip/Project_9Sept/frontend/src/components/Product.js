import './Product.css';
import {Link} from 'react-router-dom';

const Product = () => {
	return (<div className="products">
		<img src="https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-8-2.jpg" alt="OnePlus 9T" className="product_image" />
		<div className="Product__info">
			<p className="info__name"></p>
			<p className="info__description">
				Lorem ipsum
			</p>
			<p className="info__price">Rs 4000</p>
			<p>
			<Link className="info__button" to={'/product/${111}'}>View Product</Link>
			</p>
		</div>
		</div>)
};
export default Product;