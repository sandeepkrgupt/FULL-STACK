
import './App.css';
import io from 'socket.io-client';
import { useState } from 'react';
import ChatComponent from './Chat';

const socket = io.connect("http://localhost:3001");

function App() {
  const [username, setUsername] = useState("");
  const [room, setRoom] = useState("");

  
  const joinRoom = () => {
    if(username !== "" && room !== "") {
      socket.emit("join_room", room);
    }
  }

  return (
    <div className="App">
      <h3>Join A Room</h3>
      <div>
        <input type="text" placeholder="Enter User Name" onChange={(event) => { 
          setUsername(event.target.value) }
          } />
        <input type="text" placeholder="Enter Room ID" onChange={(event) => { 
          setRoom(event.target.value) }
        } />
        <button type="button" onClick={joinRoom}>Join Room</button>
        <ChatComponent socket={socket} username={username} room={room} />
      </div>
    </div>
  );
}

export default App;
