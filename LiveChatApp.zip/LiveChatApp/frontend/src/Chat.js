import { useEffect, useState } from "react";
import ScrollToBottom from 'react-scroll-to-bottom';

const ChatComponent = ({ socket, username, room }) => {
    const [currentMessage, setCurrentMessage] = useState();
    const [messageList, setMessageList] = useState([]);
    const sendMessage = async () => {
        if (currentMessage !== "") {
            const messageData = {
                room: room,
                author: username,
                message: currentMessage,
                time: new Date(Date.now()).getHours() + ":" + new Date(Date.now()).getMinutes()
            }
            await socket.emit("send_message", messageData);
            setMessageList((list) => [...list, messageData]);
            setCurrentMessage("");
        };
    };

    useEffect(() => {
        socket.on("receive_message", (data) => {
            setMessageList((list) => [...list, data])
        });
    }, [socket]);

    return (
        <div className="chat-window">
            <div className="chat-header">
                <p>Live Chat : <span style={{textTransform: 'uppercase'}}>&nbsp;{username}</span></p>
            </div>
            <div className="chat-body">
                <ScrollToBottom className="message-container">
                {
                    messageList.map((msgContetnt) => {
                        return (
                            <div className="message" id={username === msgContetnt.author ? "you" : "other"}>
                                <div>
                                    <div>
                                        <div className="message-content">
                                            <p>{msgContetnt.message}</p>
                                        </div>
                                    </div>
                                    <div>
                                        <div className="message-meta">
                                            <p id="time">{msgContetnt.time}</p>
                                            <p id="author">{msgContetnt.author}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )
                    })
                }
                </ScrollToBottom>
                
            </div>
            <div className="chat-footer">
                <input id="msgBox" type="text" value={currentMessage} placeholder="hey.." onChange={
                    (event) => {
                        setCurrentMessage(event.target.value)
                    }}
                    onKeyPress={
                        (event) => {
                            event.key === "Enter" && sendMessage();
                    }}
                />
                <button onClick={sendMessage}>Send</button>
            </div>
        </div>
    )
}

export default ChatComponent;