import './ProductScreen.css';

const ProductScreen = () => {
	return (
		<div className="productscreen">Product screen</div>
		);
};

export default ProductScreen;