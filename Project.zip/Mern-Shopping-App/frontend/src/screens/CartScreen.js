import './CartScreen.css';

const CartScreen = () => {
	return (
		<div className="cartscreen">Cart screen</div>
		);
};

export default CartScreen;