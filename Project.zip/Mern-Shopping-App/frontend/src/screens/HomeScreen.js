import './HomeScreen.css';

const HomeScreen = () => {
	return (
		<div className="homescreen">Home screen</div>
		);
};

export default HomeScreen;