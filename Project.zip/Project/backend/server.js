//require("dotenv").config();
const express = require('express');
const connectDB = require('./config/db');
const ProductRoutes = require('./routes/ProductRoutes');
connectDB();
const app = express();
app.use(express.jsson());
app.use('/api/mern-shopping-product', productRoutes);
const PORT = process.env.PORT || 5000; 
app.listen(PORT, () => console.log(`Server is running on port ${PORT}`));

