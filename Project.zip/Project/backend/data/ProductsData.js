const products = [
{
	name: "MI 9 Pro",
	imageUrl: 'https://unsplash.com/photos/83ypHTv6J2M',
	description: 'Mobile phone',
	price: 18000,
	countInStock:100

},{
	name: "Samsung galaxy note 10",
	imageUrl: 'https://unsplash.com/photos/83ypHTv6J2M',
	description: 'Mobile phone',
	price: 45000,
	countInStock:30

},{
	name: "Oneplus node 2",
	imageUrl: 'https://unsplash.com/photos/83ypHTv6J2M',
	description: 'Mobile phone',
	price: 32000,
	countInStock:230

},{
	name: "Iphone 11",
	imageUrl: 'https://unsplash.com/photos/83ypHTv6J2M',
	description: 'Mobile phone',
	price: 60000,
	countInStock:10

}
];

module.exports = products;