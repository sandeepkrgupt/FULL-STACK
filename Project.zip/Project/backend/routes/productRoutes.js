const express = req('express');
const router = express.Router();


// @desc - get all product from db
//@route - get api/product
//@access - public
router.get('/', (req, res) => {

});

// @desc - get a product by id from db
//@route - get api/product/:id
//@access - public
router.get('/:id', (req, res) => {

});

module.exports = router;