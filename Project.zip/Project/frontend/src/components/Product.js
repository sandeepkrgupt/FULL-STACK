import './Product.css';
import {Link} from 'react-router-dom';

const Product = (imageUrl, name, price, description, productId) => {
	return (<div className="products">
		<img src={imageUrl} alt={name} className="product_image" />
		<div className="Product__info">
			<p className="info__name">{name}</p>
			<p className="info__description">
				{description}
			</p>
			<p className="info__price">Rs. {price}</p>
			<p>
			<Link className="info__button" to={'/product/${productId}'}>View Product</Link>
			</p>
		</div>
		</div>)
};
export default Product;