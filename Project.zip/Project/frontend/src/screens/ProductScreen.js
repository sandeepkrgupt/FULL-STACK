import './ProductScreen.css';

const ProductScreen = () => {
	return (
		<div className="productscreen">
		<div className="productscreen__left">
		<div className="left__image">
		<img src="https://fdn2.gsmarena.com/vv/pics/oneplus/oneplus-8-2.jpg" alt="OnePlus 9T" />
		<p className="left__name">Description:</p>
		<p>
		Lorem ipsum dolor sit amet, velit non pulvinar scelerisque, tellus orci feugiat mauris, in egestas elit metus vel augue. Sed ipsum eros, finibus eget augue vehicula, laoreet dignissim elit. Mauris ante nisi, faucibus sit amet arcu in, efficitur fermentum metus.
		
		</p>
		</div>
		<div className="left__info">
		<p className="left__name">Product Name</p>
		<p className="left__name">Rs - 4000</p>
		
		</div>
		</div>
		<div className="productscreen__right">
		<div className="right__info">
		<p >
		Price : <span>Rs 4000</span>
		</p>
		<p>
		Status: <span></span>
		</p>
		<p>
		Qty
		<select>
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
			<option value="4">4</option>
		</select>
		</p>
		<p>
		<button type="button">Add To Cart</button>
		</p>
		</div>
		</div>
		</div>
		);
};

export default ProductScreen;