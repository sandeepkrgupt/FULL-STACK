import React from 'react';
class CompTwo extends React.Component {
    render() {
      return <h1>Welcome to Dashboard, Are you Ready to FLY.</h1>
    }
  }
export default CompTwo;