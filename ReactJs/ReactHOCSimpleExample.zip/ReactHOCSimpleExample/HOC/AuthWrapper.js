import React from 'react';

function AuthWrapper(XYZ) {
    return class extends React.Component {
      render() {
        if (this.props.isLoggedIn) {
          return <XYZ {...this.props} />
        }
        return <h3>You're not logged in ☹️</h3>
      }
    }
  }
export default AuthWrapper;  