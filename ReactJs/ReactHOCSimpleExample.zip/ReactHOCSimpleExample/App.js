import React from 'react';
import AuthWrapper from './HOC/AuthWrapper';
import CompTwo from './HOC/CompTwo';

class App extends React.Component {
  constructor(props) {
    super(props);    
    this.state = {
      isLoggedIn: false
    }
  }
  
  toggleAuth = () => {
    this.setState((state, props) => 
    ({ isLoggedIn: !state.isLoggedIn }))
  }

  
  render() {
    const { isLoggedIn } = this.state
    return (
      <div>
        <button onClick={this.toggleAuth}>{isLoggedIn ? 'Logout' : 'Login' }</button>
        <WrappedTwo isLoggedIn={isLoggedIn} />
      </div>
    );
  }
}
const WrappedTwo = AuthWrapper(CompTwo);
//EnhancedComponent = HigherOrderComponent(WrapprComponent);

export default App;