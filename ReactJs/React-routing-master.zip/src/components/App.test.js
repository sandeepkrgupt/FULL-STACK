import React from 'react';
import { shallow, mount } from 'enzyme';
import renderer from 'react-test-renderer';
import ConnectedHome, { Home } from './Home';
import { configureStore } from 'redux-mock-store';
import { Provider } from 'react-redux';

import { addInputs, subtractInputs } from '../actions/calculatorActions';
import { createStore } from 'redux';
import calculatorReducers from '../reducers/calculatorReducers';

// Snapshot for Home React Component
describe('>>>H O M E --- Snapshot', () => {
  it('+++capturing Snapshot of Home', () => {
    const renderedValue = renderer.create(<Home output={10} />).toJSON();
    expect(renderedValue).toMatchSnapshot();
  });
});
//*******************************************************************************************************
describe('>>>H O M E --- Shallow Render REACT COMPONENTS', () => {
const can = {
  name: 'pamplemousse',
  ounces: 12,
};

it('has 12 ounces', () => { 
    expect(can.ounces).toBe(12);
  });

  it('has a sophisticated name', () => {
    expect(can.name).toBe('pamplemousse');
  });
});
//*******************************************************************************************************
