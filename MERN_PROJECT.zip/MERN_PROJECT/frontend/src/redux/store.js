import {createStore, combineReducers, applyMiddleware} from 'redux';
/*
One of the main use cases for this middleware is for handling actions
that might not be synchronous, for example, using axios to send a GET 
request.
*/
import thunk from 'redux-thunk';
import {composeWithDevTools} from 'redux-devtools-extension';

import {cartReducer} from './reducers/cartReducers';
import {getProductDetailsReducer, getProductsReducer} from './reducers/productReducers';

/* const reducer is root reducer here */
const reducer = combineReducers({
	cart: cartReducer,
	getProducts: getProductsReducer,
	getProductDetails: getProductDetailsReducer
});

const middleware = [thunk];

const cartFromLocalStorage = localStorage.getItem("cart") ? JSON.parse(localStorage.getItem("cart")) : [];
console.log('cartFromLocalStorage', cartFromLocalStorage)
const INITIAL_STATE = {
	cart: {
		cartItems: cartFromLocalStorage
	}
}

const store = createStore(
	reducer,
	INITIAL_STATE,
	composeWithDevTools(applyMiddleware(...middleware))
);

export default store;